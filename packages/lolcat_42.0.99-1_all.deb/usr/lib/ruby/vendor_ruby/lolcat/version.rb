module Lolcat
  VERSION = "42.0.99"
end
